import Imprimir from "./imprimirMensaje.mjs";

Imprimir.Despedida()
