let arreglo = ['p', 's', 'x', 'k']
arreglo.map((item,posicion, array)=>{
    console.log(item, posicion, array);
})

let m = new Map() 
m //?

let n = new Map([
    ["uno", 1],
    ["dos", 2]
])

n // ?
n.uno // ?
// n[uno] // ?
window.n = n