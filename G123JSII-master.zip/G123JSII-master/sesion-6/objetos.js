// Objeto JSON
const objeto = {
    "nombre": "Juan Pérez",
    "profesion": "Contador",
    "edad": 30,
    "paqueteria": ["Excel", "Word", "PowerPoint"],
    "disponibilidadParaViajar": true,
    "experiencia": {
        "antigüedad": 12,
        "nivel": "Gerente"
    }
}

// Objeto Javascript
const ejemplo = {
    nombre: "Juan Pérez",
    profesion: "Contador",
    edad: 30,
    paqueteria: ["Excel", "Word", "PowerPoint"],
    disponibilidad_Para_Viajar: true,
    experiencia: {
        antigüedad: 12,
        nivel: "Gerente"
    }
}
