const idiomaPagina = require('./lenguaje')

test('Regresamos la URL según el idioma seleccionado', ()=>{
    // expect(idiomaPagina("es-mx")).tobe("/about-us")
})
