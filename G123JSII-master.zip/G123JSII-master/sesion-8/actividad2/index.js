const sumar = (a, b) => a + b
const restar = (a, b) => a - b
const multiplicar = (a, b) => a * b
const dividir = (a, b) => a / b

module.exports = {
    sumar,
    restar, 
    multiplicar,
    dividir
}
