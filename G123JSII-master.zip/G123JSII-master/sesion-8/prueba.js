const suma = (a, b) => {
    return a + b
}
module.exports = suma
