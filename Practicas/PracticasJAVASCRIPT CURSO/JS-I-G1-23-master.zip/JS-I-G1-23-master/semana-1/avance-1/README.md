# Archivos del proyecto

Avance de proyecto según las especificaciones del PDF

# Recomendaciones

Instalar extensión Live server para VS Code

- ritwickdey.LiveServer

Instalar extensión (Pixel Perfect para Chrome)[https://chrome.google.com/webstore/detail/perfectpixel-by-welldonec/dkaagdgjmgdmbnecmcefdhjekcoceebi/related]
