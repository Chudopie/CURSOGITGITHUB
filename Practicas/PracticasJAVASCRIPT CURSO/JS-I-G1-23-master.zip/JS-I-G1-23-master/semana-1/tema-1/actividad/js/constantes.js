// Ejercicio 4

/* 
    Las constantes no pueden ser
    reasignadas a otro valor una
    vez que son declaradas.
*/

// Limpiamos la consola
console.clear()

const WEB = "google.com";
const IP = "10.10.1.100"

console.log(WEB, IP);